import { useLayoutEffect } from "react";
import { applyTheme, themeCssVars } from "@/lib/theme";
import { useThemeStore } from "@/lib/theme-store";

export function ThemeRoot({ children }: { children: React.ReactNode }) {
  const theme = useThemeStore((s) => s.theme);

  useLayoutEffect(() => {
    applyTheme(theme);
  }, [theme]);

  return (
    <div
      className="flex min-h-dvh flex-col bg-background text-foreground"
      style={themeCssVars(theme) as React.CSSProperties}
    >
      {children}
    </div>
  );
}
