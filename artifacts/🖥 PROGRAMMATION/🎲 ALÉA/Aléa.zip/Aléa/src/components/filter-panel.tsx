import { PATTERN_HINTS, PATTERN_IDS, PATTERN_LABELS, type PatternId } from "@/lib/types";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";

export function FilterPanel({
  patterns,
  count,
  batch,
  element,
  onToggle,
  onCount,
  onBatch,
  onElement,
}: {
  patterns: PatternId[];
  count: number;
  batch: 1 | 3;
  element: string;
  onToggle: (id: PatternId) => void;
  onCount: (n: number) => void;
  onBatch: (n: 1 | 3) => void;
  onElement: (v: string) => void;
}) {
  return (
    <section className="flex flex-col gap-6">
      <div>
        <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted-foreground">
          Filtres de motif
        </p>
        <p className="mt-2 max-w-prose text-sm leading-relaxed text-muted-foreground">
          Ils n'imposent pas le lore. Ils orientent la forme des mots :
          sujets, styles, noms, sensations. Rien de coché = tout le lexique.
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          {PATTERN_IDS.map((id) => {
            const on = patterns.includes(id);
            return (
              <button
                key={id}
                type="button"
                title={PATTERN_HINTS[id]}
                onClick={() => onToggle(id)}
                className={cn(
                  "h-10 rounded-full border px-3 text-sm transition-opacity duration-150",
                  on
                    ? "border-transparent bg-primary text-primary-foreground"
                    : "border-border bg-transparent text-foreground hover:bg-accent",
                )}
              >
                {PATTERN_LABELS[id]}
              </button>
            );
          })}
        </div>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <label className="flex flex-col gap-2">
          <span className="text-xs font-medium uppercase tracking-[0.16em] text-muted-foreground">
            Nombre de mots
          </span>
          <div className="flex items-center gap-3">
            <input
              type="range"
              min={3}
              max={7}
              value={count}
              onChange={(e) => onCount(Number(e.target.value))}
              className="w-full accent-primary"
              aria-label="Nombre de mots-clés"
              suppressHydrationWarning
            />
            <span className="w-6 text-right font-display text-lg tabular-nums">
              {count}
            </span>
          </div>
        </label>

        <fieldset className="flex flex-col gap-2">
          <legend className="text-xs font-medium uppercase tracking-[0.16em] text-muted-foreground">
            Tirage
          </legend>
          <div className="flex gap-2">
            {([1, 3] as const).map((n) => (
              <button
                key={n}
                type="button"
                onClick={() => onBatch(n)}
                className={cn(
                  "h-10 flex-1 rounded-md border text-sm",
                  batch === n
                    ? "border-transparent bg-primary text-primary-foreground"
                    : "border-border text-foreground hover:bg-accent",
                )}
              >
                {n === 1 ? "Une idée" : "Trois idées"}
              </button>
            ))}
          </div>
        </fieldset>
      </div>

      <label className="flex flex-col gap-2">
        <span className="text-xs font-medium uppercase tracking-[0.16em] text-muted-foreground">
          Élément d'ancrage
        </span>
        <Input
          value={element}
          onChange={(e) => onElement(e.target.value)}
          placeholder="Un personnage, un lieu, un objet — n'importe lequel"
        />
        <span className="text-sm leading-relaxed text-muted-foreground">
          Le dé reste aveugle au projet. L'ancrage sert seulement à écrire le
          rapport, après coup.
        </span>
      </label>
    </section>
  );
}
