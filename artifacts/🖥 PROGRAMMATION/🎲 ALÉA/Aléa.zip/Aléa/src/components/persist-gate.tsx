import { useEffect } from "react";
import { useAleas } from "@/lib/store";
import { applyTheme } from "@/lib/theme";
import { useThemeStore } from "@/lib/theme-store";

export function PersistGate() {
  useEffect(() => {
    let cancelled = false;
    void (async () => {
      await useAleas.persist.rehydrate();
      await useThemeStore.persist.rehydrate();
      if (cancelled) return;
      applyTheme(useThemeStore.getState().theme);
      useThemeStore.getState().setHydrated(true);
    })();
    return () => {
      cancelled = true;
    };
  }, []);
  return null;
}
