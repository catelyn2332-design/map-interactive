import { create } from "zustand";
import { persist } from "zustand/middleware";
import { applyTheme, DEFAULT_THEME, type SavedPalette, type Theme } from "./theme";

type ThemeState = {
  theme: Theme;
  palettes: SavedPalette[];
  hydrated: boolean;
  setHydrated: (value: boolean) => void;
  setTheme: (patch: Partial<Theme>) => void;
  replaceTheme: (theme: Theme) => void;
  savePalette: (name: string) => void;
  applyPalette: (id: string) => void;
  removePalette: (id: string) => void;
};

export const useThemeStore = create<ThemeState>()(
  persist(
    (set, get) => ({
      theme: DEFAULT_THEME,
      palettes: [],
      hydrated: false,
      setHydrated: (value) => set({ hydrated: value }),
      setTheme: (patch) => {
        const theme = { ...get().theme, ...patch };
        applyTheme(theme);
        set({ theme });
      },
      replaceTheme: (theme) => {
        applyTheme(theme);
        set({ theme });
      },
      savePalette: (name) => {
        const trimmed = name.trim();
        if (!trimmed) return;
        const palette: SavedPalette = {
          id: `${Date.now().toString(16)}`,
          name: trimmed,
          theme: { ...get().theme },
        };
        set((s) => ({ palettes: [palette, ...s.palettes].slice(0, 24) }));
      },
      applyPalette: (id) => {
        const found = get().palettes.find((p) => p.id === id);
        if (!found) return;
        applyTheme(found.theme);
        set({ theme: found.theme });
      },
      removePalette: (id) =>
        set((s) => ({ palettes: s.palettes.filter((p) => p.id !== id) })),
    }),
    {
      name: "alea-theme",
      skipHydration: true,
      partialize: (s) => ({ theme: s.theme, palettes: s.palettes }),
    },
  ),
);
