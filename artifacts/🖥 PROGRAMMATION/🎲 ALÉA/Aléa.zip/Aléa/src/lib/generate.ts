import { allTokens } from "./lexicon";
import type { Idea, PatternId, Token } from "./types";

function mulberry32(seed: number) {
  let t = seed >>> 0;
  return () => {
    t += 0x6d2b79f5;
    let x = t;
    x = Math.imul(x ^ (x >>> 15), x | 1);
    x ^= x + Math.imul(x ^ (x >>> 7), x | 61);
    return ((x ^ (x >>> 14)) >>> 0) / 4294967296;
  };
}

function pickN(pool: Token[], n: number, rand: () => number): Token[] {
  const copy = [...pool];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [copy[i], copy[j]] = [copy[j]!, copy[i]!];
  }
  const seen = new Set<string>();
  const out: Token[] = [];
  for (const token of copy) {
    const key = token.word.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(token);
    if (out.length >= n) break;
  }
  return out;
}

function cap(word: string) {
  return word.charAt(0).toUpperCase() + word.slice(1);
}

function w(tokens: Token[], i: number) {
  return tokens[i % tokens.length]!.word;
}

function buildTitle(tokens: Token[], rand: () => number): string {
  const first = tokens[0]!;
  const a = first.word;
  const b = w(tokens, 1);
  const c = w(tokens, 2);
  const long = a.includes(" ") || a.length > 18;
  const forms: string[] = [`${cap(a)}`, `${cap(a)} — ${b}`, `${cap(a)} / ${cap(b)}`];
  if (!long && first.pattern !== "role" && first.pattern !== "sensation") {
    forms.push(`Sous ${a}`, `${cap(a)} de ${b}`, `${cap(a)}, ${b}`, `Contre ${a}`);
  }
  if (first.pattern === "nom") {
    forms.push(`${a}`, `${a} : ${b}`);
  }
  if (c && c !== a) forms.push(`${cap(c)} : ${a}`);
  return forms[Math.floor(rand() * forms.length)]!;
}


function buildDescription(tokens: Token[], rand: () => number): string {
  const k = (i: number) => w(tokens, i);
  const forms = [
    `Prendre ${k(0)} comme matière. Laisser ${k(1)} contaminer un geste banal. Noter ce que ${k(2)} fait aux silences.`,
    `Un traitement ${k(0)} appliqué à une scène trop calme. ${cap(k(1))} entre sans permission. ${cap(k(2))} reste après.`,
    `Inventaire : ${k(0)}, ${k(1)}, ${k(2)}. Ne pas expliquer. Observer lequel des trois devient une habitude.`,
    `${cap(k(0))} n'est pas un décor. C'est une contrainte. ${cap(k(1))} en est le coût. ${cap(k(2))} en est la fuite.`,
    `Faire durer ${k(0)} trop longtemps. Couper dès que ${k(1)} devient joli. Garder ${k(2)} comme reste inutilisable.`,
    `Hypothèse brute : si ${k(0)} et ${k(1)} occupent la même pièce, ${k(2)} cesse d'être métaphorique.`,
    `Réduire l'idée à une texture : ${k(0)}. Une règle : ${k(1)}. Un accident : ${k(2)}.`,
    `Quelqu'un copie ${k(0)} sans le comprendre. ${cap(k(1))} se transmet mieux que les faits. ${cap(k(2))} trahit la copie.`,
    `Commencer par ${k(0)}. Interrompre par ${k(1)}. Terminer trop tôt, au moment où ${k(2)} devient lisible.`,
    `Refuser le symbole évident. ${cap(k(0))} reste concret. ${cap(k(1))} reste gênant. ${cap(k(2))} n'aide personne.`,
  ];
  return forms[Math.floor(rand() * forms.length)]!;
}

function buildRapport(tokens: Token[], element: string, rand: () => number): string {
  const trimmed = element.trim();
  if (!trimmed) {
    return "Ancrez un personnage, un lieu, un objet ou une relation dans le champ ci-dessus, puis relancez — le rapport s'écrira contre cet élément, sans le protéger.";
  }
  const k = (i: number) => w(tokens, i);
  const e = trimmed;
  const forms = [
    `Avec ${e} : ${k(0)} devient une habitude secrète. ${cap(k(1))} explique un geste que personne n'avait nommé. ${cap(k(2))} ouvre une contradiction utile.`,
    `${e} ne change pas d'objectif — seulement de texture. ${cap(k(0))} s'installe dans sa routine. ${cap(k(1))} rend un silence plus cher. ${cap(k(2))} peut servir de levier.`,
    `Coller ${k(0)} à ${e} jusqu'à ce que ça frotte. Si ${k(1)} paraît trop décoratif, le donner à quelqu'un d'autre. Garder ${k(2)} pour ${e} seul.`,
    `${e} rencontre ${k(0)} comme un outil, pas comme un destin. ${cap(k(1))} en révèle la maladresse. ${cap(k(2))} reste après la scène.`,
    `Faire de ${k(0)} le langage privé de ${e}. ${cap(k(1))} est ce que les autres voient. ${cap(k(2))} est ce que ${e} ne dira pas.`,
    `${e} est déjà trop défini. ${cap(k(0))} le désaxe. ${cap(k(1))} empêche le retour à l'équilibre. ${cap(k(2))} propose une nouvelle compétence, ou une nouvelle peur.`,
    `Mettre ${e} dans un rapport de travail avec ${k(0)}. La relation n'est pas affective d'abord : c'est une tâche. ${cap(k(1))} en est le matériel. ${cap(k(2))} en est l'erreur.`,
    `Si ${e} ignore ${k(0)}, l'histoire tourne en rond. ${cap(k(1))} force un choix. ${cap(k(2))} en est la trace, même si le choix n'a pas lieu.`,
  ];
  return forms[Math.floor(rand() * forms.length)]!;
}

export function generateIdea(input: {
  patterns: PatternId[];
  count: number;
  element: string;
  seed?: number;
}): Idea {
  const seed = input.seed ?? (Math.floor(Math.random() * 0xffffffff) ^ Date.now());
  const rand = mulberry32(seed);
  const pool = allTokens(input.patterns);
  const n = Math.min(7, Math.max(3, input.count));
  const keywords = pickN(pool, n, rand);
  return {
    id: `${seed.toString(16)}-${Date.now().toString(16)}`,
    createdAt: Date.now(),
    keywords,
    title: buildTitle(keywords, rand),
    description: buildDescription(keywords, rand),
    rapport: buildRapport(keywords, input.element, rand),
    element: input.element.trim(),
    patterns: [...input.patterns],
  };
}

export function formatIdea(idea: Idea): string {
  const keys = idea.keywords.map((k) => k.word).join(" · ");
  return `* ${idea.title}\n\n* ${idea.description}\n\n* ${idea.rapport}\n\nMots-clés : ${keys}`;
}
