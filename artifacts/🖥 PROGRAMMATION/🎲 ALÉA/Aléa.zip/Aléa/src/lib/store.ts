import { create } from "zustand";
import { persist } from "zustand/middleware";
import { generateIdea } from "./generate";
import type { Idea, PatternId } from "./types";

type State = {
  patterns: PatternId[];
  count: number;
  batch: 1 | 3;
  element: string;
  rolling: boolean;
  ideas: Idea[];
  archive: Idea[];
  setPatterns: (patterns: PatternId[]) => void;
  togglePattern: (id: PatternId) => void;
  setCount: (count: number) => void;
  setBatch: (batch: 1 | 3) => void;
  setElement: (element: string) => void;
  roll: () => void;
  save: (idea: Idea) => void;
  remove: (id: string) => void;
  clearArchive: () => void;
};

export const useAleas = create<State>()(
  persist(
    (set, get) => ({
      patterns: [],
      count: 5,
      batch: 1,
      element: "",
      rolling: false,
      ideas: [],
      archive: [],
      setPatterns: (patterns) => set({ patterns }),
      togglePattern: (id) =>
        set((s) => ({
          patterns: s.patterns.includes(id)
            ? s.patterns.filter((p) => p !== id)
            : [...s.patterns, id],
        })),
      setCount: (count) => set({ count }),
      setBatch: (batch) => set({ batch }),
      setElement: (element) => set({ element }),
      roll: () => {
        const { patterns, count, batch, element } = get();
        const next = Array.from({ length: batch }, () =>
          generateIdea({ patterns, count, element }),
        );
        set({ rolling: true, ideas: next });
        if (typeof window !== "undefined") {
          window.setTimeout(() => set({ rolling: false }), 720);
        } else {
          set({ rolling: false });
        }
      },
      save: (idea) =>
        set((s) => {
          if (s.archive.some((a) => a.id === idea.id)) return s;
          return { archive: [idea, ...s.archive].slice(0, 80) };
        }),
      remove: (id) => set((s) => ({ archive: s.archive.filter((a) => a.id !== id) })),
      clearArchive: () => set({ archive: [] }),
    }),
    {
      name: "alea-inconnu",
      skipHydration: true,
      partialize: (s) => ({
        patterns: s.patterns,
        count: s.count,
        batch: s.batch,
        element: s.element,
        ideas: s.ideas,
        archive: s.archive,
      }),
    },
  ),
);
