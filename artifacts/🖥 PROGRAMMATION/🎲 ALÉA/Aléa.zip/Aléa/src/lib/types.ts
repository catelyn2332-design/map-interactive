export const PATTERN_IDS = [
  "sujet",
  "theme",
  "style",
  "nom",
  "adjectif",
  "sensation",
  "phenomene",
  "objet",
  "lieu",
  "role",
] as const;

export type PatternId = (typeof PATTERN_IDS)[number];

export type Token = {
  word: string;
  pattern: PatternId;
};

export type Idea = {
  id: string;
  createdAt: number;
  keywords: Token[];
  title: string;
  description: string;
  rapport: string;
  element: string;
  patterns: PatternId[];
};

export const PATTERN_LABELS: Record<PatternId, string> = {
  sujet: "Sujet",
  theme: "Thème",
  style: "Style",
  nom: "Nom",
  adjectif: "Adjectif",
  sensation: "Sensation",
  phenomene: "Phénomène",
  objet: "Objet",
  lieu: "Lieu",
  role: "Rôle",
};

export const PATTERN_HINTS: Record<PatternId, string> = {
  sujet: "Matières et motifs à traiter",
  theme: "Idées abstraites",
  style: "Textures formelles",
  nom: "Noms propres inventés",
  adjectif: "Qualités inattendues",
  sensation: "Perceptions physiques",
  phenomene: "Événements sans cause claire",
  objet: "Choses concrètes rares",
  lieu: "Espaces non cartographiés",
  role: "Fonctions humaines odd",
};
